# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.7.4] - 2026-10-20
### Changed
- Updated translations

## [1.7.3] - 2026-10-10
### Fixed
- Fixed startup crash on Android 11 and below

## [1.7.2] - 2026-10-10
### Changed
- Compatibility with newer Android devices using 16KB pages
- Updated translations

### Fixed
- Fixed automatic word capitalization when renaming recordings ([#397])
- Fixed accidental page changes while seeking through recordings ([#82])

## [1.7.1] - 2026-02-14
### Changed
- Updated translations

### Fixed
- Fixed file size calculations to use SI decimal units (divide by 1000)

## [1.7.0] - 2026-01-30
### Added
- Option to customize recording filename pattern with datetime placeholders ([#15])
- Added support for custom fonts

### Changed
- Removed per-item overflow menu from recordings list in favor of long-press options ([#229])
- Updated player tab icon ([#256])
- Updated translations

## [1.6.0] - 2025-12-16
### Changed
- Updated translations

### Fixed
- Fixed recording from external apps ([#273])

## [1.5.1] - 2025-11-06
### Changed
- Playback is now paused when external audio devices are disconnected ([#247])
- Updated translations

## [1.5.0] - 2025-10-29
### Changed
- Compatibility updates for Android 15 & 16
- Updated translations

## [1.4.0] - 2025-09-01
### Added
- Added "Microphone mode" option (replacement for "Audio source" option) ([#16])

### Changed
- Updated translations

## [1.3.5] - 2025-08-26
### Changed
- Reduced recording label size to align with material guidelines ([#96])

### Fixed
- Fixed issue recording with external microphones ([#16])

## [1.3.4] - 2025-08-20
### Changed
- Updated translations

### Removed
- Removed unnecessary `Audio source` preference ([#16])

### Fixed
- Fixed clipped filenames in the recordings list ([#96])

## [1.3.3] - 2025-07-29
### Changed
- Updated translations

### Fixed
- Fixed `Open with` not working on some devices ([#185])

## [1.3.2] - 2025-07-19
### Changed
- Updated translations

### Fixed
- Fixed `Open with` not showing app chooser dialog ([#176])

## [1.3.1] - 2025-06-17
### Changed
- Marked app as beta
- Updated translations

## [1.3.0] - 2025-06-10
### Added
- Option to choose recording sample rate ([#33])

### Changed
- Improved wording in the recording cancellation dialog ([#141])
- Moved recording-related preferences to a new "Recording" section ([#147])
- Updated translations

### Removed
- Removed outdated option for hiding notification ([#150])

## [1.2.0] - 2025-05-20
### Added
- Added confirmation dialog when cancelling recording ([#106])

### Changed
- Updated translations

## [1.1.3] - 2025-01-17
### Changed
- Added more translations

### Fixed
- Fixed cut-off or corrupted recordings ([#81])

## [1.1.2] - 2025-01-16
### Added
- Added experimental notice when recording MP3 ([#81])

### Changed
- Added more translations

## [1.1.1] - 2025-01-16
### Changed
- Mark MP3 format as experimental ([#81])
- Added more translations

## [1.1.0] - 2025-01-11
### Added
- Added button to cancel recording ([#57])
- Added option to keep screen on during recording ([#67])
- Added option to move recordings when changing recordings folder

### Changed
- Replaced checkboxes with switches
- Other minor bug fixes and improvements
- Added more translations

### Removed
- Removed support for Android 7 and older versions

### Fixed
- Fixed issue with delete recording button ([#40])
- Fixed issue with invalid button states ([#47])
- Fixed app not responding errors [#22]

## [1.0.0] - 2024-02-17
### Added
- Initial release

[#15]: https://github.com/FossifyOrg/Voice-Recorder/issues/15
[#16]: https://github.com/FossifyOrg/Voice-Recorder/issues/16
[#22]: https://github.com/FossifyOrg/Voice-Recorder/issues/22
[#33]: https://github.com/FossifyOrg/Voice-Recorder/issues/33
[#40]: https://github.com/FossifyOrg/Voice-Recorder/issues/40
[#47]: https://github.com/FossifyOrg/Voice-Recorder/issues/47
[#57]: https://github.com/FossifyOrg/Voice-Recorder/issues/57
[#67]: https://github.com/FossifyOrg/Voice-Recorder/issues/67
[#81]: https://github.com/FossifyOrg/Voice-Recorder/issues/81
[#82]: https://github.com/FossifyOrg/Voice-Recorder/issues/82
[#96]: https://github.com/FossifyOrg/Voice-Recorder/issues/96
[#106]: https://github.com/FossifyOrg/Voice-Recorder/issues/106
[#141]: https://github.com/FossifyOrg/Voice-Recorder/issues/141
[#147]: https://github.com/FossifyOrg/Voice-Recorder/issues/147
[#150]: https://github.com/FossifyOrg/Voice-Recorder/issues/150
[#176]: https://github.com/FossifyOrg/Voice-Recorder/issues/176
[#185]: https://github.com/FossifyOrg/Voice-Recorder/issues/185
[#229]: https://github.com/FossifyOrg/Voice-Recorder/issues/229
[#247]: https://github.com/FossifyOrg/Voice-Recorder/issues/247
[#256]: https://github.com/FossifyOrg/Voice-Recorder/issues/256
[#273]: https://github.com/FossifyOrg/Voice-Recorder/issues/273
[#397]: https://github.com/FossifyOrg/Voice-Recorder/issues/397

[Unreleased]: https://github.com/FossifyOrg/Voice-Recorder/compare/1.7.4...HEAD
[1.7.4]: https://github.com/FossifyOrg/Voice-Recorder/compare/1.7.3...1.7.4
[1.7.3]: https://github.com/FossifyOrg/Voice-Recorder/compare/1.7.2...1.7.3
[1.7.2]: https://github.com/FossifyOrg/Voice-Recorder/compare/1.7.1...1.7.2
[1.7.1]: https://github.com/FossifyOrg/Voice-Recorder/compare/1.7.0...1.7.1
[1.7.0]: https://github.com/FossifyOrg/Voice-Recorder/compare/1.6.0...1.7.0
[1.6.0]: https://github.com/FossifyOrg/Voice-Recorder/compare/1.5.1...1.6.0
[1.5.1]: https://github.com/FossifyOrg/Voice-Recorder/compare/1.5.0...1.5.1
[1.5.0]: https://github.com/FossifyOrg/Voice-Recorder/compare/1.4.0...1.5.0
[1.4.0]: https://github.com/FossifyOrg/Voice-Recorder/compare/1.3.5...1.4.0
[1.3.5]: https://github.com/FossifyOrg/Voice-Recorder/compare/1.3.4...1.3.5
[1.3.4]: https://github.com/FossifyOrg/Voice-Recorder/compare/1.3.3...1.3.4
[1.3.3]: https://github.com/FossifyOrg/Voice-Recorder/compare/1.3.2...1.3.3
[1.3.2]: https://github.com/FossifyOrg/Voice-Recorder/compare/1.3.1...1.3.2
[1.3.1]: https://github.com/FossifyOrg/Voice-Recorder/compare/1.3.0...1.3.1
[1.3.0]: https://github.com/FossifyOrg/Voice-Recorder/compare/1.2.0...1.3.0
[1.2.0]: https://github.com/FossifyOrg/Voice-Recorder/compare/1.1.3...1.2.0
[1.1.3]: https://github.com/FossifyOrg/Voice-Recorder/compare/1.1.2...1.1.3
[1.1.2]: https://github.com/FossifyOrg/Voice-Recorder/compare/1.1.1...1.1.2
[1.1.1]: https://github.com/FossifyOrg/Voice-Recorder/compare/1.1.0...1.1.1
[1.1.0]: https://github.com/FossifyOrg/Voice-Recorder/compare/1.0.0...1.1.0
[1.0.0]: https://github.com/FossifyOrg/Voice-Recorder/releases/tag/1.0.0
